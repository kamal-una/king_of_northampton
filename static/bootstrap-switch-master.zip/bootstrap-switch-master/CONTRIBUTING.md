If you want help to fix bugs or propose a feature:

- Checkout `develop` branch
- Always work on this branch for fixes
- Once done, submit us your Pull Requests. Always pick `develop` as destination branch

Thank you.
